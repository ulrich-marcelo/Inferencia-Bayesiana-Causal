# -*- coding: utf-8 -*-
from Gaussiana import *
from Habilidad import *
from Evento import *
from collections import defaultdict
import math
from copy import copy

class Historia(object):
    def __init__(self, eventos, priors=defaultdict(lambda: Gaussian(0.0, 3.0)) ):
        self.eventos = eventos
        self.priors = priors
        self.habilidades = [ [[Habilidad() for integrante in equipo] for equipo in evento] for evento in eventos]
    #
    def __repr__(self):
        return f'Historia(Eventos={len(eventos)})'
    #
    def forward_propagation(self):
        h = self
        ultimo_mensaje = copy(h.priors)

    def backward_propagation(self):
        h = self
        ultimo_mensaje = defaultdict(lambda: Gaussian(0.0, math.inf))

    def posteriors(self):
        return [[[habilidad.posterior for habilidad in equipo] for equipo in evento] for evento in self.habilidades]


