# -*- coding: utf-8 -*-
from Historia import *

eventos = [ [["a"],["b"]],
            [["b"],["a"]] ]

h = Historia(eventos)
h.forward_propagation()
h.backward_propagation()
h.posteriors()
